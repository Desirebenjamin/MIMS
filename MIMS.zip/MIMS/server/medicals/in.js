const http = require("http");
const https = require("https");
const fs = require("fs");
const express = require("express");
const units = require("./routes/Units");
const bodyParser = require("body-parser");
const departments = require("./routes/Departments");
const equipment = require("./routes/Equipment");
const engineer = require("./routes/Engineers");
const location = require("./routes/Location");
const repair = require("./routes/Repairs");
const cors = require("cors");
const notifactions = require("./routes/Notifications");
const maintainance = require("./routes/Maintanance");
const app = express();
const { Server } = require("socket.io");
const validateToken = require("./routes/CodeValidate");
const pool = require("./config/db");
const details = require("./routes/Details");
// const options = {
//   key: fs.readFileSync(
//     "/etc/letsencrypt/live/qrcodemedicalequipmentinventory.work.gd/privkey.pem"
//   ),
//   cert: fs.readFileSync(
//     "/etc/letsencrypt/live/qrcodemedicalequipmentinventory.work.gd/fullchain.pem"
//   ),
// };
app.use("/images", express.static("images"));
app.use("/readme", express.static("./out"));
app.use(
  cors({
    origin: "*",
  })
);
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.use("/validate-token", validateToken);
app.use("/units", units);
app.use("/departments", departments);
app.use("/equipment", equipment);
app.use("/engineer", engineer);
app.use("/location", location);
app.use("/repair", repair);

app.use("/notifications", notifactions);
app.use("/maintainance", maintainance);
app.use("/details", details);

// const server = https.createServer(options, app);
const server = http.createServer(app);

const io = require("socket.io")(server, {
  cors: {
    origin: "*",
    methods: ["GET", "POST"],
  },
});

io.on("connection", (socket) => {
  //   console.log(socket.id);
  console.log("A user connected");

  socket.on("disconnect", () => {
    console.log("A user disconnected");
  });
});
app.post("/engreport", async (req, res, next) => {
  let engineerId =
    req.body.engineerId == undefined ? "noeng" : req.body.engineerId;

  const equipmentId = req.body.equipmentId;

  const status = req.body.status;
  let sql;
  const reportdate = new Date().toString();
  let sql1 = `INSERT INTO Repair (idRepair, Status, Engineer_idEngineer, Equipment_idEquipment, Units_idUnits,reportdate)
     VALUES (NULL, '${status}', NULL, '${equipmentId}', NULL,'${reportdate}')`;
  let sql2 = `INSERT INTO Repair (idRepair, Status, Engineer_idEngineer, Equipment_idEquipment, Units_idUnits,reportdate)
     VALUES (NULL, '${status}', '${engineerId}', '${equipmentId}', NULL,'${reportdate}')`;
  let statesql = `UPDATE equipment SET Status = 'A' WHERE idEquipment = '${equipmentId}' `;

  try {
    if (engineerId === "noeng") {
      const unit = await pool.execute(sql1);

      res.status(200).json(unit[0]);

      io.emit("eng-repair", "New equipment repaired");
    } else {
      const unit = await pool.execute(sql2);

      res.status(200).json(unit[0]);
      io.emit("eng-repair", "New equipment repaired");
    }
    const data = await pool.execute(statesql);
  } catch (error) {
    res.status(200).json(error);
  }
});
app.post("/unitreport", async (req, res, next) => {
  // const engineerId = req.body.engineerId===undefined?'NULL':req.body.engineerId
  const equipmentId = req.body.equipmentId;
  const unitId = req.body.unitId;
  const status = req.body.status;
  const reportdate = new Date().toString();
  console.log(req.body);
  let sql = `INSERT INTO Repair (idRepair, Status, Engineer_idEngineer, Equipment_idEquipment, Units_idUnits,reportdate)
     VALUES (NULL, '${status}', NULL, '${equipmentId}', '${unitId}','${reportdate}')`;
  let statesql = `UPDATE equipment SET Status = 'E' WHERE idEquipment = '${equipmentId}' `;
  try {
    const unit = await pool.execute(sql);
    const data = await pool.execute(
      `INSERT INTO Unitnotifications(idUnitNotifications, date, Equipment_idEquipment, Units_idUnits) VALUES (NULL,'${reportdate}','${equipmentId}','${unitId}')`
    );
    const response = await pool.execute(statesql);
    io.emit("unit-report", "New equip reported");
    res.status(200).json(data[0]);
  } catch (error) {
    res.status(200).json(error);
  }
});

app.use((req, res, next) => {
  const error = new Error("Not found");
  error.status = 404;
  next(error);
});
app.use((error, req, res, next) => {
  res.status(error.status || 400).json({
    error: {
      message: error.message,
    },
  });
});
const port = 3000;

server.listen(port, () => console.log(`listening from port ${port}`));
