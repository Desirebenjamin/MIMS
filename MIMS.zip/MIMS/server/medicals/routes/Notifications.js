const express = require("express");

const notifactions = express();
const pool = require("../config/db");

notifactions.get("/", async (req, res) => {
  const data = await pool.execute(
    "SELECT UnitNotifications.idUnitNotifications, unitnotifications.date, equipment.idEquipment, units.idUnits, unitnotifications.state, equipment.Name as equipName, equipment.image, equipment.Status,  units.name AS unitName, equipment.description FROM `Unitnotifications` JOIN Equipment ON Equipment_idEquipment = idequipment JOIN Units ON Units_idUnits = idunits order by date desc;"
  );
  try {
    res.status(200).json(data[0]);
  } catch (error) {
    res.status(200).json(error);
  }
});

notifactions.post("/:id", async (req, res, body) => {
  console.log(req.params.id);
  const data = await pool.execute(
    `UPDATE UnitNotifications SET state = 'seen' WHERE idUnitNotifications = '${req.params.id}'`
  );
  try {
    res.status(200).json(data[0]);
  } catch (error) {
    res.status(200).json(error);
  }
});

module.exports = notifactions;
