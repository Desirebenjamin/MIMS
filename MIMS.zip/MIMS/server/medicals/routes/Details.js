const express = require("express");
const pool = require("../config/db");
const app = express();
const io = require("socket.io")();

const details = express();

details.get("/", async (req, res, next) => {
  let sql = `SELECT COUNT(idEquipment) as equipNo FROM Equipment`;
  let sqlrepairs = `SELECT COUNT(idRepair) as repairNo FROM Repair`;
  let sqlrepairsA = `SELECT COUNT(idRepair) as repairNoA FROM Repair where Status='A'`;
  let sqlrepairsE = `SELECT COUNT(idRepair) as repairNoE FROM Repair where Status='E'`;

  try {
    const unit = await pool.execute(sql);
    const data = await pool.execute(sqlrepairs);
    const repairsA = await pool.execute(sqlrepairsA);
    const repairsE = await pool.execute(sqlrepairsE);
    res.status(200).json({
      equipNo: unit[0][0].equipNo,
      repairsNo: data[0][0].repairNo,
      repairsNoA: repairsA[0][0].repairNoA,
      repairsNoE: repairsE[0][0].repairNoE,
    });
    // res.status(200).json(unit[0]);
  } catch (error) {
    res.status(400).json(error);
  }
});
details.post("/", async (req, res, next) => {
  const engId = req.body.engId;
  let sql = `select COUNT(Equipment_idEquipment) as repairNo ,engineer.username from Repair  join engineer on engineer.idEngineer = repair.Engineer_idEngineer WHERE Engineer_idEngineer='${engId}';`;
  try {
    const data = await pool.execute(sql);
    res.status(200).json(data[0]);
  } catch (error) {
    res.status(403).json(error);
  }
});
details.get("/:id", async (req, res, body) => {
  const id = req.params.id;
  let sql = `SELECT * FROM Repair where idRepair='${id}'`;
  try {
    const unit = await pool.execute(sql);
    res.status(200).json(unit[0]);
  } catch (error) {
    res.status(400).json(error);
  }
});

module.exports = details;
