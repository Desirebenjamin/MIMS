const express = require("express");
const pool = require("../config/db");

const department = express();

department.get("/", async (req, res, next) => {
  const sql = "SELECT * FROM `Department`";
  try {
    const unit = await pool.execute(sql);
    res.status(200).json(unit[0]);
  } catch (error) {
    res.status(400).json(error);
  }
});
department.post("/:depart", async (req, res, next) => {
  const department = req.params.depart;
  console.log(department);
  const sql = `INSERT INTO department (idDepartment, Name) VALUES (NULL, '${department}')`;
  try {
    const unit = await pool.execute(sql);
    res.status(200).json(unit[0]);
  } catch (error) {
    res.status(400).json(error);
  }
});
module.exports = department;
