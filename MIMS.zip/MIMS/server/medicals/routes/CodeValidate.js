const express = require("express");
const validToken = express();
const jwt = require("jsonwebtoken");
validToken.post("/", (req, res, next) => {
  // Get the JWT token from the request
  const token = req.headers.authorization.split(" ")[1];

  // Decode the JWT token
  const decoded = jwt.verify(token, "medical");

  //   Check if the token is expired
  //   res.send(decoded);
  if (decoded.exp < Date.now()) {
    // next(new Error());
    throw new Error("The token has expired.");
  }

  // Check if the token is valid
  if (!decoded) {
    throw new Error("The token is not valid.");
  }

  // Get the user ID from the payload

  // Return the user ID
  res.send(decoded);
});
module.exports = validToken;
