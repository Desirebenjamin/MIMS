const express = require("express");
const pool = require("../config/db");
const jwt = require("jsonwebtoken");

const units = express();
units.get("/all", async (req, res, next) => {
  let sql = "SELECT * FROM `Units`";

  try {
    const units = await pool.execute(sql);
    res.status(200).json(units[0]);
  } catch (error) {
    res.status(400).json(error);
  }
});

units.post("/login", async (req, res, next) => {
  const { username, password } = req.body;
  console.log(username);
  const sql = `SELECT * FROM Units WHERE username='${username}' AND password='${password}'`;

  try {
    const [unitRows] = await pool.execute(sql);
    if (unitRows.length === 0) {
      return res.status(401).json({ message: "Invalid credentials" });
    }

    const unit = unitRows[0];
    const token = jwt.sign(
      {
        id: unit.idUnits,
        username: unit.username,
        role: "user",
        iat: Date.now(),
        exp: Date.now() + 1000 * 60 * 60 * 1, // 1 hour
      },
      "medical"
    );

    res.status(200).json({ token });
  } catch (error) {
    res
      .status(500)
      .json({ message: "An error occurred while processing your request" });
  }
});
units.get("/:id", async (req, res, next) => {
  const id = req.params.id;
  let sql = `SELECT * FROM Units where idUnits='${id}'`;
  try {
    const unit = await pool.execute(sql);
    res.status(200).json(unit[0]);
  } catch (error) {
    res.status(400).json(error);
  }
});

units.post("/", async (req, res, next) => {
  const id = req.body.id;
  const name = req.body.name;
  const phone = req.body.phone;
  const location = req.body.location;
  const username = req.body.username;
  const password = req.body.password;
  let sql = `INSERT INTO Units (idUnits, name, Phone, Location, username, password)
     VALUES (NULL, '${name}', '${phone}', '${location}', '${username}', '${password}')`;
  try {
    const unit = await pool.execute(sql);
    res.status(200).json(unit);
  } catch (error) {
    res.status(400).json(error);
  }
});
module.exports = units;
