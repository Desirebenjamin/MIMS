const express = require("express");
const pool = require("../config/db");
const app = express();
const io = require("socket.io")();

const repair = express();

repair.get("/", async (req, res, next) => {
  let sql = `SELECT Repair.idRepair, Repair.reportdate ,Repair.status,  Equipment.idEquipment,Equipment.image, Equipment.idEquipment, Equipment.Name as equipName, Units.name as unitName FROM Repair INNER JOIN Equipment ON idEquipment=Equipment_idEquipment INNER JOIN Units on idUnits=Units_idUnits order by Repair.reportdate desc`;
  try {
    const unit = await pool.execute(sql);
    res.status(200).json(unit[0]);
  } catch (error) {
    res.status(400).json(error);
  }
});
repair.get("/repairtimes", async (req, res, next) => {
  let sql = `SELECT Equipment.Name,Repair.Status, count(*) as equipRepairTimes from Repair inner join Equipment on Equipment.idEquipment=Equipment_idEquipment where Repair.Status='A' GROUP by Equipment_idEquipment limit 7;`;
  try {
    const unit = await pool.execute(sql);
    res.status(200).json(unit[0]);
  } catch (error) {
    res.status(400).json(error);
  }
});

repair.get("/:id", async (req, res, body) => {
  const id = req.params.id;
  let sql = `SELECT * FROM Repair where idRepair='${id}'`;
  try {
    const unit = await pool.execute(sql);
    res.status(200).json(unit[0]);
  } catch (error) {
    res.status(400).json(error);
  }
});

module.exports = repair;
