const express = require("express");
const pool = require("../config/db");
const jwt = require("jsonwebtoken");

const engineer = express();

// Sign up route
engineer.post("/signup", async (req, res) => {
  const id = req.body.id;
  const name = req.body.name;
  const phone = req.body.phone;
  const pass = req.body.password;
  const passphrase = req.body.passphrase;
  let sql = `INSERT INTO Engineer (idEngineer, username, Phone, password) VALUES (NULL, '${name}', '${phone}', '${pass}')`;
  try {
    if (passphrase === "eng123") {
      const result = await pool.execute(sql);
      res.status(200).json(result);
    } else {
      res.status(400).json("An error occured");
    }
  } catch (error) {
    res.status(400).json(error);
  }
});

// Login route
engineer.post("/login", async (req, res, next) => {
  const { username, password } = req.body;
  console.log(username);
  const sql = `SELECT * FROM Engineer WHERE username='${username}' AND password='${password}'`;

  try {
    const [unitRows] = await pool.execute(sql);
    if (unitRows.length === 0) {
      return res.status(401).json({ message: "Invalid credentials" });
    }

    const unit = unitRows[0];
    const token = jwt.sign(
      {
        id: unit.idEngineer,
        username: unit.username,
        role: "engineer",
        iat: Date.now(),
        exp: Date.now() + 1000 * 60 * 60 * 1, // 1 hour
      },
      "medical"
    );

    res.status(200).json({ token });
  } catch (error) {
    res
      .status(500)
      .json({ message: "An error occurred while processing your request" });
  }
});
module.exports = engineer;
