const express = require('express')
const location = express()
const pool = require('../config/db')

location.get('/',async(req,res,next)=>{
    let sql= 'SELECT * FROM `equipment_location`'
    console.log('hello');
    try {
        const unit = await pool.execute(sql)
        res.status(200).json(unit[0])
    } catch (error) {
        res.status(400).json(error)
    }
})

location.post('/',async(req,res,next)=>{
    const engineerId = req.body.engineerId
    const equipmentId = req.body.equipmentId
    console.log(equipmentId);
    let sql= `INSERT INTO Equipment_location (idEquipment_location, EngineerID, Equipment_idEquipment)
     VALUES (NULL, '${engineerId}', '${equipmentId}');`
    try {
        const unit = await pool.execute(sql)
        res.status(200).json(unit[0])
    } catch (error) {
        res.status(400).json(error)
    }
})
module.exports = location