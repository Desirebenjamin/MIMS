const express = require("express");
const pool = require("../config/db");
const multer = require("multer");

const equipment = express();

const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, "images/");
  },
  filename: function (req, file, cb) {
    cb(null, new Date().toDateString() + file.originalname);
  },
});
const manualsStorage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, "manuals/");
  },
  filename: function (req, file, cb) {
    cb(null, new Date().toDateString() + file.originalname);
  },
});

const imageUpload = multer({ storage: storage });
const manualUpload = multer({ storage: manualsStorage });

equipment.get("/", async (req, res, next) => {
  let sql = `SELECT * from Equipment;`;
  try {
    const unit = await pool.execute(sql);
    res.status(200).json({
      data: unit[0],
    });
  } catch (error) {
    res.status(400).json(error);
  }
});
equipment.get("/:id", async (req, res, body) => {
  const id = req.params.id;
  let sql = `SELECT * from Equipment  where idEquipment='${id}'`;
  try {
    const unit = await pool.execute(sql);
    res.status(200).json(unit[0]);
  } catch (error) {
    res.status(400).json(error);
  }
});
equipment.post("/equip", async (req, res, body) => {
  const name = req.body.name;

  let sql = `SELECT * from Equipment  WHERE equipment.Name LIKE '${name}%' or  equipment.idEquipment LIKE '${name}%'`;
  try {
    const unit = await pool.execute(sql);
    res.status(200).json(unit[0]);
  } catch (error) {
    res.status(400).json(error);
  }
});

equipment.post("/", imageUpload.single("photo"), async (req, res, next) => {
  const image = `/images/${req.file.filename}`;
  console.log(image);
  const name = req.body.name;
  const serialNo = req.body.serialNo;
  const manufacturer = req.body.manufacturer;
  const Installation_Date = "2023-03-16 21:29:54";
  // console.log(Installation_Date);
  const lifeTime = req.body.lifetime;
  const status = req.body.status;
  const category = req.body.category;
  const description = req.body.description;
  const model = req.body.model;
  // console.log(description);
  // let sql= `INSERT INTO Equipment (idEquipment, Name, Serial_no, Manufacturer, Installation_Date, Lifetime, Status, image,description,Equipment_category_idEquipment_category) VALUES (NULL, '${name}', '${serialNo}', '${manufacturer}', '${Installation_Date}', '${lifeTime}', '${status}','${image}','${description}' , '${category}')`
  // let sql = `INSERT INTO Equipment (idEquipment, Name, Serial_no, Manufacturer, Installation_Date, Lifetime, Status, image, description, category,model) VALUES (NULL, '${name}', '${serialNo}', '${manufacturer}', '${Installation_Date}', '${lifeTime}', '${status}','${image}','${description}' , '${category}','${model}');`;
  let sql = `INSERT INTO Equipment (idEquipment, Name, Serial_no, Manufacturer, Installation_Date, Lifetime, Status, image, description, category, model) VALUES (NULL, '${name}', '${serialNo}', '${manufacturer}', '${Installation_Date}', '${lifeTime}', '${status}', '${image}', '${description}', '${category}','${model}')`;
  try {
    const unit = await pool.execute(sql);
    res.status(200).json(unit);
  } catch (error) {
    res.status(200).json(error.message);
  }
});
equipment.post("/manuals", manualUpload.single("manual"), async (req, res) => {
  const manual = `/manuals/${req.file.filename}`;
  console.log(req.body.equipId);
  const equipId = req.body.equipId;
  try {
    const data = await pool.execute(
      `INSERT INTO manuals  VALUES (NULL,'${manual}','${equipId}')`
    );
    res.status(200).json(data);
  } catch (error) {
    res.status(200).json(error);
  }
});

equipment.post("/category/:category", async (req, res, next) => {
  const category = req.params.category;
  console.log(category);
  let sql = `INSERT INTO Equipment_category (idEquipment_category, Category_name) VALUES (NULL, '${category}')`;
  try {
    const category = await pool.execute(sql);
    res.status(200).json(category);
  } catch (error) {
    res.status(400).json(error);
  }
});

module.exports = equipment;
