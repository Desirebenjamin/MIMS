const express = require("express");
const maintainance = express();
const pool = require("../config/db");

maintainance.get("/", async (req, res) => {
  const sql =
    "SELECT * FROM `Maintanance` JOIN equipment ON Equipment_idEquipment = idEquipment  ";
  try {
    const data = await pool.execute(sql);
    res.status(200).json(data[0]);
  } catch (error) {
    res.status(200).json(error);
  }
});
maintainance.post("/", async (req, res) => {
  const day = req.body.day;
  const prev = new Date().toLocaleDateString();
  const idEquip = req.body.idEquip;
  const catequip = req.body.catequip;
  const sql = `INSERT INTO Maintanance (idMaintanance, Maintanance_days, Previous_maintanance, Equipment_idEquipment, Equipment_Equipment_category_idEquipment_category)
   VALUES (NULL, '${day}', '${prev}', '${idEquip}', '${catequip}');`;
  try {
    const data = await pool.execute(sql);
    res.status(200).json(data[0]);
  } catch (error) {
    res.status(200).json(error);
  }
});

module.exports = maintainance;
