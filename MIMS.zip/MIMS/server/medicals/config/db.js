const mysql = require("mysql2");

const pool = mysql.createPool({
  // host: "database-1.cs7ocyq447t1.ap-northeast-1.rds.amazonaws.com",
  host: "localhost",
  port: "3306",
  user: "root",
  password: "",
  database: "medicalinventory",
});
let sql = "SELECT * FROM `Engineer`";
pool.execute(sql, (err, result) => {
  if (err) {
    console.log(err);
  } else {
    console.log(result);
  }
});

module.exports = pool.promise();
