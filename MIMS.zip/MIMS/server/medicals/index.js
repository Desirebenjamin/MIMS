const http = require("http");
const https = require("https");
const fs = require("fs");
const express = require("express");
const units = require("./routes/Units");
const bodyParser = require("body-parser");
const departments = require("./routes/Departments");
const equipment = require("./routes/Equipment");
const engineer = require("./routes/Engineers");
const location = require("./routes/Location");
const repair = require("./routes/Repairs");
const cors = require("cors");
const notifactions = require("./routes/Notifications");
const maintainance = require("./routes/Maintanance");
const app = express();
const { Server } = require("socket.io");
const validateToken = require("./routes/CodeValidate");
const pool = require("./config/db");
const details = require("./routes/Details");

/**
 * Middleware to serve static images
 */
app.use("/images", express.static("images"));

/**
 * Middleware to serve README.md documentation
 */
app.use("/read", express.static("./Readme.md"));

/**
 * Middleware to handle Cross-Origin Resource Sharing (CORS)
 */
app.use(
  cors({
    origin: "*",
  })
);

/**
 * Middleware to parse request bodies
 */
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

/**
 * Middleware for token validation
 */
app.use("/validate-token", validateToken);

/**
 * Routes for handling units
 */
app.use("/units", units);

/**
 * Routes for handling departments
 */
app.use("/departments", departments);

/**
 * Routes for handling equipment
 */
app.use("/equipment", equipment);

/**
 * Routes for handling engineers
 */
app.use("/engineer", engineer);

/**
 * Routes for handling locations
 */
app.use("/location", location);

/**
 * Routes for handling repairs
 */
app.use("/repair", repair);

/**
 * Routes for handling notifications
 */
app.use("/notifications", notifactions);

/**
 * Routes for handling maintenance
 */
app.use("/maintainance", maintainance);

/**
 * Routes for handling details
 */
app.use("/details", details);

/**
 * Create an HTTP server
 */
const server = http.createServer(app);

/**
 * Initialize Socket.IO with the server instance
 */
const io = require("socket.io")(server, {
  cors: {
    origin: "*",
    methods: ["GET", "POST"],
  },
});

/**
 * Socket.IO event listener for connection
 */
io.on("connection", (socket) => {
  console.log("A user connected");

  /**
   * Socket.IO event listener for disconnection
   */
  socket.on("disconnect", () => {
    console.log("A user disconnected");
  });
});

/**
 * Express route handler for POST /engreport
 */
app.post("/engreport", async (req, res, next) => {
  /**
   * @typedef {Object} ExpressRequest
   * @property {Object} body - Request body
   * @property {string} body.engineerId - Engineer ID
   * @property {string} body.equipmentId - Equipment ID
   * @property {string} body.status - Status
   */

  /** @type {ExpressRequest} */
  const { engineerId, equipmentId, status } = req.body;
  const reportdate = new Date().toString();

  let sql;
  if (engineerId === undefined) {
    sql = `INSERT INTO Repair (idRepair, Status, Engineer_idEngineer, Equipment_idEquipment, Units_idUnits, reportdate)
      VALUES (NULL, '${status}', NULL, '${equipmentId}', NULL, '${reportdate}')`;
  } else {
    sql = `INSERT INTO Repair (idRepair, Status, Engineer_idEngineer, Equipment_idEquipment, Units_idUnits, reportdate)
      VALUES (NULL, '${status}', '${engineerId}', '${equipmentId}', NULL, '${reportdate}')`;
  }

  const statesql = `UPDATE equipment SET Status = 'A' WHERE idEquipment = '${equipmentId}'`;

  try {
    const unit = await pool.execute(sql);
    res.status(200).json(unit[0]);
    io.emit("eng-repair", "New equipment repaired");

    const data = await pool.execute(statesql);
  } catch (error) {
    res.status(200).json(error);
  }
});

/**
 * Express route handler for POST /unitreport
 */
app.post("/unitreport", async (req, res, next) => {
  /**
   * @typedef {Object} ExpressRequest
   * @property {Object} body - Request body
   * @property {string} body.equipmentId - Equipment ID
   * @property {string} body.unitId - Unit ID
   * @property {string} body.status - Status
   */

  /** @type {ExpressRequest} */
  const { equipmentId, unitId, status } = req.body;
  const reportdate = new Date().toString();

  const sql = `INSERT INTO Repair (idRepair, Status, Engineer_idEngineer, Equipment_idEquipment, Units_idUnits, reportdate)
    VALUES (NULL, '${status}', NULL, '${equipmentId}', '${unitId}', '${reportdate}')`;

  const statesql = `UPDATE equipment SET Status = 'E' WHERE idEquipment = '${equipmentId}'`;

  try {
    const unit = await pool.execute(sql);
    const data = await pool.execute(
      `INSERT INTO Unitnotifications(idUnitNotifications, date, Equipment_idEquipment, Units_idUnits) VALUES (NULL, '${reportdate}', '${equipmentId}', '${unitId}')`
    );
    io.emit("unit-report", "New equipment reported");
    res.status(200).json(data[0]);
  } catch (error) {
    res.status(200).json(error);
  }
});

/**
 * Express middleware for handling unknown routes
 */
app.use((req, res, next) => {
  const error = new Error("Not found");
  error.status = 404;
  next(error);
});

/**
 * Express middleware for error handling
 */
app.use((error, req, res, next) => {
  res.status(error.status || 400).json({
    error: {
      message: error.message,
    },
  });
});

/**
 * Port for the Express server to listen on
 * @constant {number}
 */
const port = 3000;

/**
 * Start the Express server
 */
server.listen(port, () => console.log(`Listening on port ${port}`));
